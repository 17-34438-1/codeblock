<?php
include("class/users.php");
$register=new users;
extract($_POST);
$img_name=$_FILES['image']['name'];
$tmp_name=$_FILES['image']['tmp_name'];
move_uploaded_file($tmp_name,"image/".$img_name);
$query="insert into student values('','$n','$e','$p','$r','$pcon','$s','$img_name')";
if($register->signup($query))
{
	$register->url("index.php?run=success");
}
?>