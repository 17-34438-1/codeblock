<?php


if(isset($_POST['login'])){
	
	$email=$_POST['email'];
	$password=$_POST['password'];
	if($username==$user and $password==$passw){
		
		if(isset($_POST['remember'])){
		setcookie ('email',$email,time()+60*60*7);
		setcookie('password',$username,time()+60*60*7);
		
		}
		session_start();
		$_SESSION['email']=$email;
header("location:login.php");
	}
	else 
	{
		"Username or password is invalid.<br>click here to <a href='login.php'>try again</a>";
}
}


		
		
?>

<?php
session_start();
include("class/users.php");
$signin=new users;
extract($_POST);
if($signin->signin($e,$p))
{
$signin->url("home.php");	
}
else{
$signin->url("index.php?run=failed");
}
	
?>