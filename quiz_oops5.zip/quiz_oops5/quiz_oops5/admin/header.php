<!DOCTYPE HTML>
<html lang="en_US">
<head>
<meta charset="UTF-8">
<title>Student Management System</title>
<link href="../css/style.css"rel="stylesheet"type="text/css">

</head>
<body bgcolor="#0000ff";>


