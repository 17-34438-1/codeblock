<?php
include('../class/dbcon.php');
$id=$_REQUEST['id'];
  $qury="DELETE FROM `student` WHERE `id`='$id';"; 
$run=mysqli_query($con,$qury);
if($run == true)
{
?>
<script>
alert('Data Deleted Successfully.');
window.open('deletestudent.php ','_self');
</script>
<?php
}



?>