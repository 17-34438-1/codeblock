<?php
if(isset($_COOKIE['username'] )and isset($_COOKIE['password'])){
	$username=$_COOKIE['username'];
	$password=$_COOKIE['password'];
	echo $username;
	echo "<script>
	document.getElementById('username').value='$username';
	document.getElementById('password').value='$password';
	</script>";
}
?>



<?php
 include('server.php');
 
 ?>
<!DOCTYPE html>
<html>
<head>

<title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  
</head>
<body>
<div class="header">
  	<h2>Login</h2>
  </div>
 <form method="post" action="login.php">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  		<label>Username</label>
  		<input type="text" name="username" >
  	</div>
  	<div class="input-group">
  		<label>Password</label>
  		<input type="password" name="password">
  	</div>
	
<tr><td  colspan="2"align="center">
	<input type ="checkbox" name="remember">Remember Me</td></tr>
	
  	<div class="input-group">
  		<button type="submit" class="btn" name="login_user">Login</button>
  	</div>
  	<p>
  		Not yet a member? <a href="register.php">Sign up</a>
  	</p>
  </form>
</body>
</html>