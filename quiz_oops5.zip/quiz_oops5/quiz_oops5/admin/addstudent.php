<?php
session_start();


      if(isset($_SESSION['username']))
     {
	echo "";
     }
        else
		{
	header('location:../index.php');
       }
?>

<?php
error_reporting(0);
   $name= $_POST['name'];
	$email= $_POST['email'];
	
	$pass=$_POST['pass'];
	$rollno=$_POST['rollno'];
	$pcon= $_POST['pcon'];
	$std= $_POST['std'];
	
	
	echo "FullName: ".$name."<br/>";
	echo "email:".$email."<br/>";
	echo "pass:".$pass."<br/>";
	echo "Rollno:".$rollno."<br/>";
	echo "Parents Contact no:".$pcon."<br/>";
	echo "Standerd:".$std."<br/>";
	
?>

	

<?php
include('header.php');
include('titlehead.php');
?>
<DOCTYPE html>
<html>
<head>
<script>
function validateForm() {
 var x = document.forms["myForm"]["name"].value;
  var x1 = document.forms["myForm"]["email"].value;
  
   var x2 = document.forms["myForm"]["pass"].value;
   var x3 = document.forms["myForm"]["rollno"].value;
      var x4 = document.forms["myForm"]["pcon"].value;
	        var x5 = document.forms["myForm"]["std"].value;
				        var x6 = document.forms["myForm"]["image"].value;



  if (x == "") {
    alert("name must be filled out");
    return false;
  }
  if (x1 == "") {
    alert("email must be filled out");
    return false;
  }
  
  if (x2 == "") {
    alert("pass must be filled out");
    return false;
  }
  if (x3 == "") {
    alert("rollno must be filled out");
    return false;
  }
  if (x4 == "") {
    alert("parent contract must be filled out");
    return false;
  }
  if (x5 == "") {
    alert("std must be filled out");
    return false;
  }
  if (x6 == "") {
    alert("image must be filled out");
    return false;
  }
}
</script>

</head>
<body>
<h1 id="h1"></h1>
	<div id="div1">
	</div>

	<img src="200.gif" style="display: none;" id="loadimage">
<form name="myForm" method="post" action="addstudent.php" onsubmit="return validateForm()" enctype="multipart/form-data">
<table align="center"border="1" style="width:70%;margin-top:40px;">

<tr>
<th>Full Name</th>
<td><input type="text" id="name" name="name" placeholder="Enter Full Name">

</td>
</tr>

<tr>
   <th>Email</th>
   <td><input type="text"name="email"placeholder="Enter City">

</td>
   
   </tr>
   
   <tr class="row">
<th>Password</th>
<td><input class ="text"type="text"placeholder="Password"id="pass"name="pass">


</td>

</tr>
<tr>
<th>Roll No</th>
<td><input type="text"name="rollno"placeholder="Enter Rollno">

</td>
</tr>
   <tr>
   <th>Parents Contact no</th>
   <td><input type="text"name="pcon"placeholder="Enter the Contact no of parents">

   </td>
   </tr>
   
    <tr>
   <th>Standerd</th>
   <td><input type="number"name="std"placeholder="Enter Standerd">

   </td>
</tr>

<tr>
<th>Image</th>
<td><input type="file"name="image"</td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="submit" value="Submit" ></td>
</tr>
   

</table>
</form>
</body>
</html>

<?php
if(isset($_POST['submit']))
{
include('../class/dbcon.php');

$name=$_POST['name'];
$email=$_POST['email'];
$pass= $_POST['pass'];
$rollno=$_POST['rollno'];

$pcon=$_POST['pcon'];
$std=$_POST['std'];
$imagename= $_FILES['image']['name'];
$tempname=$_FILES['image']['tmp_name'];
move_uploaded_file($tempname,"../image/$imagename");


$qury="insert into student values('','$name','$email','$pass','$rollno','$pcon','$std','$imagename')";
$run=mysqli_query($con,$qury);
if($run == true)
{
?>
<script>
alert('Data Inserted Successfully.');
</script>
<?php
}
}
?>
