<?php
include('../class/dbcon.php');

$name=$_POST['name'];
$email=$_POST['email'];
$pass= $_POST['pass'];
$rollno=$_POST['rollno'];
$pcon=$_POST['pcon'];
$std=$_POST['standerd'];
$id = $_POST['sid'];

$imagename= $_FILES['image']['name'];
$tempname=$_FILES['image']['tmp_name'];
move_uploaded_file($tempname,"../image/$imagename");


 $qury="UPDATE  `student` SET  `name`= '$name', `email`='$email', `pass`='$pass', `rollno`='$rollno',`pcont` = '$pcon',`standerd`= '$std', `image`='$imagename' WHERE `id` = $id; ";
$run=mysqli_query($con,$qury);
if($run == true)
{
?>
<script>
alert('Data Updated Successfully.');
window.open('updateform.php?sid=<?php echo $id;?>','_self');
</script>
<?php
}



?>