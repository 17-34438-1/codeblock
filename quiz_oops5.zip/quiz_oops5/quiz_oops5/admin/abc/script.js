

	function testa(){
		//console.log('test');

		//element = document.getElementById('div1');
		//element.innerHTML = "hsgdvgsdvhsd asgdf asd asdg";

		document.getElementById('div1').innerHTML = "<h1>test</h1>";	
	}

	function getName(){
		name = document.getElementById('name').value;
		//alert(name);
		document.getElementById('div1').innerHTML = name;
	}

	function validation(){
		//
		//

		return false;
	}

	function test() {

		document.getElementById('loadimage').style.display = 'block';
		name = document.getElementById('name').value;
  		
  		var xhttp = new XMLHttpRequest();
  		xhttp.open("GET", "abc.php?name="+name, true);
  		xhttp.send();

  		xhttp.onreadystatechange = function() {
	    	if (this.readyState == 4 && this.status == 200) {
	    		document.getElementById('loadimage').style.display = 'none';
	     		document.getElementById("div1").innerHTML = this.responseText;
	    	}
  		};

	}

