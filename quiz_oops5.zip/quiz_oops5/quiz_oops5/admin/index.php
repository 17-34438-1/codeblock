



<?php 

session_start();
echo "welcome".$_SESSION['username'];

  if (!isset($_SESSION['username'])) {
	  
  	$_SESSION['msg'] = "You must log in first";
  	
  }
  
?>

<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>


   <?php
include('header.php');
?>

 <div class="dashbaord">
<table border="1" style="width:50%;" align="center">
<tr>
<td>1.</td><td><a href="addstudent.php">Add Modarator Details</a></td>
</tr>
<tr>
<td>2.</td><td><a href="updatestudent.php">Update Modarator Details</a>
</td>
</tr>
<tr>
<td>3.</td><td><a href="deletestudent.php">Delete Modararor Details</a></td>
</tr>
<tr>
<td><a href="logout.php" style="float:right"class="btn btn-primary">LOGOUT</a></td>
</tr>
</table>
</div>
		
</body>
</html>