<?php
	sleep(3);
	$name = $_GET['name'];
	$msg = "My name is: ".$name;
	
	echo $msg;

?>