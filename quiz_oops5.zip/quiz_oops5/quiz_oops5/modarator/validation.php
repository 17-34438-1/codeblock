
<?php
session_start();

$con=mysqli_connect('localhost','root');
if($con){
	
	echo "connection successful";
}
else{
	echo "no connection";
}
mysqli_select_db($con,'quiz_oops');
$email=$_POST['email'];
$pass=$_POST['pass'];
$q="select *from signup where email ='$email' && pass = '$pass'";
$run=mysqli_query($con,$q);
$run=mysqli_num_rows($run);

if($run == 1){
$_SESSION['email']=$email;
header('location:index.php');
}
		else{
			
header('location:signin_sub.php');


		}
?>
