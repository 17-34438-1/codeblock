
<?php
sleep(3);
session_start();


      if(isset($_SESSION['username']))
     {
	echo "";
     }
        else
		{
	header('location:../indexex.php');
       }
?>



	

<?php
include('header.php');
include('titlehead.php');
?>








<?php
if(isset($_POST['submit']))
{
include('../class/dbcon.php');
include("../class/users.php");
$register=new users;
$n=$_POST['n'];
$e=$_POST['e'];
$p= $_POST['p'];
$r=$_POST['r'];

$pcon=$_POST['pcon'];
$s=$_POST['s'];
$imagename= $_FILES['image']['name'];
$tempname=$_FILES['image']['tmp_name'];
move_uploaded_file($tempname,"../image/$imagename");


$query="insert into student values('','$n','$e','$p','$r','$pcon','$s','$imagename')";
if($register->signup($query))
{
	$register->url("addstudent.php?run=success");
}
}
?>
