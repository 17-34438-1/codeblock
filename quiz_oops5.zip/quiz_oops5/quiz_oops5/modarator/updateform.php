<?php
sleep(3);
session_start();


      if(isset($_SESSION['username']))
     {
	echo "";
     }
        else
		{
	header('location:../indexex.php');
       }
?>

<?php
error_reporting(0);

include('../class/dbcon.php');
$sid=$_GET['sid'];
$sql="SELECT *FROM `student` WHERE `id`='$sid'";
$run=mysqli_query($con,$sql);
$data=mysqli_fetch_assoc($run);

?>
<?php
	error_reporting(0);
	
 $name= $_POST['name'];
	$email= $_POST['email'];
	
	$pass=$_POST['pass'];
	$rollno=$_POST['rollno'];
	$pcon= $_POST['pcon'];
	$std= $_POST['std'];
	
	
     echo "FullName: ".$name."<br/>";
	echo "email:".$email."<br/>";
	echo "pass:".$pass."<br/>";
	echo "Rollno:".$rollno."<br/>";
	echo "Parents Contact no:".$pcon."<br/>";
	echo "Standerd:".$std."<br/>";
?>
<?php
if(isset($_POST['submit'])){
include('../class/dbcon.php');
$name=$_POST['name'];
if($_POST['name']==""){
	$error_msg['name']= "Name is required";
}


else if((strlen($name)<=2)){
	$error_msg['name']="Only input at least 2 digits first name";
}

$email=$_POST['email'];
if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
$error_msg['email']="Invalid email address";
}
$pass=$_POST['pass'];

if(!$pass){
$error_msg['pass']="Password is required";
}
if((strlen($pass)>=8)){
$error_msg['pass3']="Password must br 8-20";
}
$rollno=$_POST['rollno'];
if(empty($rollno)){
	$error_msg['rollno']="rollno is required";
}
else if((strlen($rollno)<=2)){
	$error_msg['rollno']="Only input at least 2 digits";
}
else if(!is_numeric($rollno)){
$error_msg['rollno']="Only number input";
}
else if((strlen($rollno)>=12)){
	$error_msg['rollno']="Only input at least 11 digits number";
}

$pcon=$_POST['pcon'];
if(empty($pcon)){
	$error_msg['pcon']="pcon is required";
}
if(!is_numeric($pcon)){
	$error_msg['pcon']="pcon is required";
}
else if(!is_numeric($pcon)){
$error_msg['pcon']="Only number input";
}
else if((strlen($pcon)>=12)){
	$error_msg['pcon']="Only input at least 11 digits number";
}
$std=$_POST['std'];
if(empty($std)){
	$error_msg['std']="standerd is required";
}
if(!is_numeric($std)){
	$error_msg['std']="standerd is required";
}
else if(!is_numeric($std)){
$error_msg['std']="Only number input";
}
else if((strlen($std)>=2)){
	$error_msg['std']="Only input at least 2 digits number";
}



}

?>

	

<?php
include('header.php');
include('titlehead.php');
?>
<DOCTYPE html>
<html>
<head>
<script type="text/javascript" src="abc/script.js"></script>
</head>
</head>
<body>
<h1 id="h1">Hello</h1>
	<div id="div1">
	</div>
	<!-- <button onclick="test()">Click!</button> -->

	<img src="200.gif" style="display: none;" id="loadimage">
	<form name="myForm" method="post" action="updatedata.php" onsubmit="return validateForm()" enctype="multipart/form-data">
<table align="center"border="1" style="width:70%;margin-top:40px;">

<tr>
<th>Full Name</th>
<td><input type="text"name="name"value=<?php echo $data['name'];?>>
<?php
if(isset($error_msg['name'])){
	echo $error_msg['name'];
}
?>
</td>
</tr>

<tr>
   <th>Email</th>
   <td><input type="text"name="email"value=<?php echo $data['email'];?>>
   <?php
if(isset($error_msg['email'])){
	echo $error_msg['email'];
}
?>
</td>
   
   </tr>
   
   <tr class="row">
<th>Password</th>
<td><input class ="text"type="password" name="pass"value=<?php echo $data['pass'];?> name="pass">
<?php
if(isset($error_msg['pass']))
{
	echo $error_msg['pass'];
}

if(isset($error_msg['pass3']))
{
	echo $error_msg['pass3'];
}
?>

</td>

</tr>
<tr>
<th>Roll No</th>
<td><input type="text"name="rollno"value=<?php echo $data['rollno'];?> >
<?php

if(isset($error_msg['rollno']))
{
	echo $error_msg['rollno'];
}

?>
</td>
</tr>
   <tr>
   <th>Parents Contact no</th>
   <td><input type="text"name="pcon"value=<?php echo $data['pcont'];?>>
   <?php

if(isset($error_msg['pcon']))
{
	echo $error_msg['pcon'];
}

?>
   </td>
   </tr>
   
    <tr>
   <th>Standerd</th>
   <td><input type="number"name="standerd"value=<?php echo $data['standerd'];?>>
   <?php

if(isset($error_msg['std']))
{
	echo $error_msg['std'];
}

?>
   </td>
</tr>

<tr>
<th>Image</th>
<td><input type="file"name="image"</td>
</tr>
<tr>
<td colspan="2"align="center">
<input type ="hidden" name="sid" value="<?php echo $data['id']; ?>"/>
<input type="submit"name="submit"value="Submit"></td>
</tr>
   

</table>
</form>
</body>
</html>


