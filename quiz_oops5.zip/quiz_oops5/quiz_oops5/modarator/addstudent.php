<?php
include('header.php');
include('titlehead.php');
?>
<DOCTYPE html>
<html>
<head>



<script type="text/javascript" src="abc/script.js"></script>
<script>
function validateForm() {
	  var x1 = document.forms["myForm"]["n"].value;
  var x2 = document.forms["myForm"]["e"].value;
   var x3 = document.forms["myForm"]["p"].value;
   var x4 = document.forms["myForm"]["r"].value;
   var x5 = document.forms["myForm"]["pcon"].value;
   var x6 = document.forms["myForm"]["s"].value;
   var x7 = document.forms["myForm"]["image"].value;
    if (x1 == "") {
    alert("name must be filled out");
    return false;
  }
	if (x2 == "") {
    alert("Email must be filled out");
    return false;
  }
  if (x3 == "") {
    alert("password must be filled out");
    return false;
  }
  if (x4 == "") {
    alert("roll must be filled out");
    return false;
  }
  if (x5 == "") {
    alert("pcontract must be filled out");
    return false;
  }
  if (x6 == "") {
    alert("standerd must be filled out");
    return false;
  }
  if (x7 == "") {
    alert("image must be filled out");
    return false;
  }
  
  
  }


</script>
</head>
<body>
<h1 id="h1">Hello</h1>
	<div id="div1">
	</div>
	<!-- <button onclick="test()">Click!</button> -->

	<img src="200.gif" style="display: none;" id="loadimage">
<form role="form"method="post"action="addstudent1.php"enctype="multipart/form-data" name="myForm" onsubmit="return validateForm()">
 <table align="center"border="1" style="width:70%;margin-top:40px;">

<tr>
<th>Full Name</th>
<td>
      <input type="text" class="form-control"name="n" id="name" placeholder="Enter name" name="name">
</td></tr>

   <tr>
   <th> Email</th>
   <td>
      
      <input type="email" class="form-control"name="e" id="email" placeholder="Enter email" name="email">
    </td></tr>
	
<tr>
<th>Password</th>
<td>
      <input type="password" class="form-control" name="p"id="pwd" placeholder="Enter password" name="pass">
</td>
</tr>  
 <tr>
 <th>Roll No</th>
 <td>
      <input type="number" class="form-control" name="r"id="roll" placeholder="Enter roll" name="rollno">
    </td>
	</tr>
	
	<tr>
	<th> Parents Contact No</th>
	<td>
      <input type="number" class="form-control" name="pcon"id="pcon" placeholder="Enter pcontact" name="pcon">
    </td>
	</tr>
	<tr>
	<th>Standerd</th>
	<td>
      <input type="number" class="form-control" name="s"id="std" placeholder="Enter standerd" name="std">
    </td>
	</tr>
	<tr>
	<th>Image</th>
	<td>
<input type="file" class="form-control" name="image">
</td>
</tr>
<tr>
<td colspan="2" align="center">
    <button type="submit" name="submit" class="btn btn-default">Submit</button>
  </td>
  </tr>
  </table>
  </form>
</body>
</html>


