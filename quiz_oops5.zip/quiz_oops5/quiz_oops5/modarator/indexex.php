<?php 
include "../class/users.php";
//session_start();
echo "welcome".$_SESSION['username'];

  if (!isset($_SESSION['username'])) {
	  
  	$_SESSION['msg'] = "You must log in first";
  	
  }
  
?>

<?php

//include "../class/users.php";
$cat=new users;
$category=$cat->cat_shows();
//print_r($category);
?>
<?php
include('header.php');
?>


<!DOCTYPE html>
<html lang="en">
  <head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">
    <link rel="canonical" href="https://getbootstrap.com/docs/3.4/examples/dashboard/">



    <link href="../css/bootstrap.min.css" rel="stylesheet">

    
    <link href="..//css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    
    <link href="../css/dashboard.css" rel="stylesheet">


   
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>

   
  </head>

  <body >

    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        
        
      </div>
    </nav><br><br><br>
<h1 align="center">Welcome Modarator Dashboard</h1>
    <div class="container-fluid">
      <div class="row">
       
      
         
<?php
			if(isset($_GET['msg'])&& !empty($_GET['msg'])){
			echo "data  insert successfully";	
				
			}
			?>
          <div class="table-responsive">
            <table class="table table-striped">
			
			
  <form method="post"action="add_quiz.php">
  <div class="form-group">
<label for="text">Question</label>
      <input type="text" class="form-control"  name="qus"  placeholder="Enter question">
    </div>
	<div class="form-group">
      <label for="text">option-1</label>
      <input type="text" class="form-control"  name="op1"  placeholder="Enter option-1">
    </div>
	<div class="form-group">
      <label for="text">option-2</label>
      <input type="text" class="form-control"  name="op2"  placeholder="Enter option-2">
    </div>
	
	<div class="form-group">
      <label for="text">option-3</label>
      <input type="text" class="form-control"  name="op3"   placeholder="Enter option-3">
    </div>
	
	<div class="form-group">
      <label for="text">option-4</label>
      <input type="text" class="form-control"   name= "op4" placeholder= "Enter option-4">
    </div>

  
	
	<div class="form-group">
      <label for="text">answer</label>
      <input type="text" class="form-control"  name="ans" placeholder="Enter answer">
    </div>
  
   	<div class ="form-group">
	
	<select class ="form-control"id="sell"name="cat">
<option value="">choose category</option>

	<?php
	foreach($category as $c)
	{
		echo "<option value=".$c['id'].">".$c['cat_name']."</option>";
		
	}
	?>
	
	
	
	</select>
	
 
   </div>
  <a href="logout.php" style="float:right"class="btn btn-primary">LOGOUT</a>
    <button type="submit" class="btn btn-default">Submit</button>


</select>
  </div>

  </form>
 </table>
	</div>
        </div>
    
 <div class="dashbaord">
<table border="1" style="width:50%;" align="center">
<tr>
<td>1.</td><td><a href="addstudent.php">Add Student Details</a></td>
</tr>
<tr>
<td>2.</td><td><a href="updatestudent.php">Update Student Details</a>
</td>
</tr>
<tr>
<td>3.</td><td><a href="deletestudent.php">Delete Student Details</a></td>
</tr>
</table>
</div>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="../js/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="../js/vendor/holder.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
