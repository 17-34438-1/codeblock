<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script> 
  function validateForm() {
	  var x1 = document.forms["myForm"]["n"].value;
  var x2 = document.forms["myForm"]["e"].value;
   var x3 = document.forms["myForm"]["p"].value;
   var x4 = document.forms["myForm"]["r"].value;
   var x5 = document.forms["myForm"]["pcon"].value;
   var x6 = document.forms["myForm"]["s"].value;
   var x7 = document.forms["myForm"]["image"].value;
    if (x1 == "") {
    alert("name must be filled out");
    return false;
  }
	if (x2 == "") {
    alert("Email must be filled out");
    return false;
  }
  if (x3 == "") {
    alert("password must be filled out");
    return false;
  }
  if (x4 == "") {
    alert("roll must be filled out");
    return false;
  }
  if (x5 == "") {
    alert("pcontract must be filled out");
    return false;
  }
  if (x6 == "") {
    alert("standerd must be filled out");
    return false;
  }
  if (x7 == "") {
    alert("image must be filled out");
    return false;
  }
  
  
  }
  </script>
  </head>
<body>
<br>
<br>
<div class="container">
<div class="row">
<div class="col-sm-12">
<div class ="panel panel-danger">
<div class ="panel-heading">Online Quiz system </div>
<div class="panel-body">Welcome Quiz World</div>
</div>
</div>
</div>
</div>
<div class="container">
<div class="row">
 <div class="col-sm-6">


  <div class="panel panel-info">


    <div class="panel-heading"><h2>Signin Form</h2></div>
	<div class="panel-body">
	<?php
	if(isset($_GET['run'])&& $_GET['run']=="failed"){
		echo "Your email or password is not correct";
	}
	?>
	
	
  <form action="signin_sub.php" method="post"name="myForm1" onsubmit="return validateForm()">
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" name="e"id="email" placeholder="Enter email" name="email">
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control"name="p" id="pwd" placeholder="Enter password" name="pwd">
    
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
  </form>
</div>
</div>
</div>

 <div class="col-sm-6">

 <div class="panel panel-info">
    <div class="panel-heading"><h2>SignUp Form</h2></div>
	<div class="panel-body">
	<?php if(isset($_GET['run'])&& $_GET['run']=="success")
	{
	echo "<mark>Your registration successfully done</mark>";
	}
	?>
  <form role="form"method="post"action="signup_sub.php"enctype="multipart/form-data" name="myForm" onsubmit="return validateForm()">
  <div class="form-group">
      <label for="name">Full Name:</label>
      <input type="text" class="form-control"name="n" id="name" placeholder="Enter name">
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control"name="e" id="email" placeholder="Enter email" name="email">
    </div>
    <div class="form-group">
      <label for="password">Password:</label>
      <input type="password" class="form-control" name="p"id="pwd" placeholder="Enter password" name="password">
    </div>
	 <div class="form-group">
      <label for="rollno">Roll No:</label>
      <input type="text" class="form-control" name="r"id="roll" placeholder="Enter roll" name="roll">
    </div>
	 <div class="form-group">
      <label for="pcon">Parents Contact:</label>
      <input type="text" class="form-control" name="pcon"id="pcon" placeholder="Enter pcontact" name="pcon">
    </div>
	 <div class="form-group">
      <label for="std">Standerd:</label>
      <input type="number" class="form-control" name="s"id="std" placeholder="Enter standerd" name="pcon">
    </div>
	<div class="form-group">
      <label for="pwd">Upload your image</label>
      <input type="file" class="form-control" name="image">
    </div>
    <button type="submit" name="submit" class="btn btn-default">Submit</button>
  </form>
</div>
</div>
  </div>
</div>
</div>

</body>
</html>
