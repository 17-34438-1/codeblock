<?php
$con=mysqli_connect('localhost','root','','quiz_oops');
if($con==false){
echo"Connection is not done";
}
else{
echo "Connection ok";
}
?>